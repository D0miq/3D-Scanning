﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLinear;

namespace OpenTKLib
{
    public class Polyline1<T> : IList<Vector3d<T>>
        where T : IEquatable<T>
    {

        public int IndexOf(Vector3d<T> item)
        {
            throw new NotImplementedException();
        }

        public void Insert(int index, Vector3d<T> item)
        {
            throw new NotImplementedException();
        }

        public void RemoveAt(int index)
        {
            throw new NotImplementedException();
        }

        public Vector3d<T> this[int index]
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public void Add(Vector3d<T> item)
        {
            throw new NotImplementedException();
        }

        public void Clear()
        {
            throw new NotImplementedException();
        }

        public bool Contains(Vector3d<T> item)
        {
            throw new NotImplementedException();
        }

        public void CopyTo(Vector3d<T>[] array, int arrayIndex)
        {
            throw new NotImplementedException();
        }

        public int Count
        {
            get { throw new NotImplementedException(); }
        }

        public bool IsReadOnly
        {
            get { throw new NotImplementedException(); }
        }

        public bool Remove(Vector3d<T> item)
        {
            throw new NotImplementedException();
        }

        public IEnumerator<Vector3d<T>> GetEnumerator()
        {
            throw new NotImplementedException();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
}
