﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenTKLib
{
    public static class MathExtensions
    {
        //public static double Pow(this Math m, double a, double b)
        //{
        //    return Convert.ToSingle(Math.Pow(a, b));

        //}

    }
}
