﻿using System;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using Microsoft.Kinect;

namespace _3DScanning
{
    public partial class Form : System.Windows.Forms.Form
    {
        private AVisualisation visualisation;

        private WriteableBitmap bitmap;

        private EventHandler<DepthFrameArrivedEventArgs> depthHandler;

        /// <summary>
        /// Creates form and inicialize kinect sensor, kinect attributes and camera space points
        /// </summary>
        public Form()
        {
            InitializeComponent();
            this.visualisation = new PointCloudRenderer(this.viewport, this.statusLB);
            this.bitmap = new WriteableBitmap(this.visualisation.Kinect.Description.Width, this.visualisation.Kinect.Description.Height, 96.0, 96.0, PixelFormats.Gray8, null);
            this.DataBinding();
            this.visualisation.Kinect.Start();
        }

        /// <summary>
        /// Destructor that frees resources
        /// </summary>
        ~Form()
        {
            if (this.viewport != null)
            {
                this.viewport.Dispose();
                this.viewport = null;
            }
        }

        /// <summary>
        /// Binds controls to kinect attributes
        /// </summary>
        private void DataBinding()
        {
            this.minDepthTB.DataBindings.Add("Value", this.visualisation.KinectAttributes, "MinDepth", false, DataSourceUpdateMode.OnPropertyChanged);
            this.maxDepthTB.DataBindings.Add("Value", this.visualisation.KinectAttributes, "MaxDepth", false, DataSourceUpdateMode.OnPropertyChanged);
            this.minDepthValueLB.DataBindings.Add("Text", this.visualisation.KinectAttributes, "MinDepth", false, DataSourceUpdateMode.OnPropertyChanged);
            this.maxDepthValueLB.DataBindings.Add("Text", this.visualisation.KinectAttributes, "MaxDepth", false, DataSourceUpdateMode.OnPropertyChanged);
            this.interpolationValueLB.DataBindings.Add("Text", this.visualisation.KinectAttributes, "Interpolation", false, DataSourceUpdateMode.OnPropertyChanged);
            this.interpolationTB.DataBindings.Add("Value", this.visualisation.KinectAttributes, "Interpolation", false, DataSourceUpdateMode.OnPropertyChanged);
            this.progressBar.DataBindings.Add("Maximum", this.visualisation.KinectAttributes, "Interpolation", false, DataSourceUpdateMode.OnPropertyChanged);
            this.generateAllCB.DataBindings.Add("Checked", this.visualisation.KinectAttributes, "GenerateAll", false, DataSourceUpdateMode.OnPropertyChanged);
            this.imageControl.image.Source = this.bitmap;
        }

        /// <summary>
        /// Event that triggers when generate button is clicked
        /// </summary>
        /// <param name="sender">Object sending the event</param>
        /// <param name="e">Event arguments</param>
        private void GenerateBT_Click(object sender, EventArgs e)
        {
            this.statusLB.Text = "Probíhá generování meshe!";
            if (this.colorCB.Checked)
            {
                this.visualisation = new ColorfulGenerator(this.progressBar, this.statusLB);
            }else
            {
                this.visualisation = new ColorlessGenerator(this.progressBar, this.statusLB);
            }
            if (this.generateAllCB.Checked)
            {
                this.visualisation = new MultiMeshGenerator();
            }
            this.progressBar.Show();          
        }

        /// <summary>
        /// Event that triggers when preview button is clicked
        /// </summary>
        /// <param name="sender">Object sending the event</param>
        /// <param name="e">Event arguments</param>
        private void PreviewBT_Click(object sender, EventArgs e)
        {
            this.visualisation = new PointCloudRenderer(this.viewport, this.statusLB);      
            this.statusLB.Text = "Probíhá vytvoření náhledu!";
        }

        private void TabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            int tabIndex = (sender as TabControl).SelectedIndex;
            if(tabIndex == 1)
            {
                this.visualisation = new DepthFrameVisualisation(this.bitmap);
                this.depthHandler = this.visualisation.Reader_FrameArrived;
            }else
            {
                this.visualisation.Kinect.RemoveEventHandler(this.depthHandler);
            }
        }
    }
}
