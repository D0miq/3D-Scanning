﻿using Microsoft.Kinect;

namespace _3DScanning
{
    abstract class AVisualisation
    {
        /// <summary>
        /// Kinect sensor
        /// </summary>
        protected KinectDepthSensor kinect;

        /// <summary>
        /// Kinect attributes
        /// </summary>
        protected KinectAttributes kinectAttributes;

        /// <summary>
        /// Number of pixel in depth frames
        /// </summary>
        protected uint depthFrameLength;

        public AVisualisation()
        {
            this.kinect = KinectDepthSensor.GetInstance();
            this.kinectAttributes = this.kinect.Attributes;
            this.depthFrameLength = this.kinect.Description.LengthInPixels;
            this.kinect.AddEventHandler(this.Reader_FrameArrived);
        }

        public abstract void Reader_FrameArrived(object sender, DepthFrameArrivedEventArgs e);

        public KinectDepthSensor Kinect
        {
            get
            {
                return this.kinect;
            }
        }

        public KinectAttributes KinectAttributes
        {
            get
            {
                return this.kinectAttributes;
            }
        }
    }
}
