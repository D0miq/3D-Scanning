﻿using Microsoft.Kinect;
using System.Globalization;
using System.IO;

namespace _3DScanning
{
    class MultiMeshGenerator : AMeshGenerator
    {
        private NumberFormatInfo nfi;
        private StreamWriter sw;

        public MultiMeshGenerator()
        {
            nfi = new NumberFormatInfo();
            nfi.NumberDecimalSeparator = ".";
            sw = new StreamWriter("allFrames.obj");
        }

        public override void Reader_FrameArrived(object sender, DepthFrameArrivedEventArgs e)
        {
            using (DepthFrame depthFrame = e.FrameReference.AcquireFrame())
            {
                if (depthFrame != null)
                {
                    using (KinectBuffer depthBuffer = depthFrame.LockImageBuffer())
                    {
                        this.framesCounter++;
                        ushort[] depthArray = GetDepthFromBuffer(depthBuffer);
                        this.kinect.Mapper.MapDepthFrameToCameraSpace(depthArray, this.csPoints);
                        CameraSpacePoint[] transformedPoints = this.CameraToWorldTransfer(this.kinect.Description.Width, this.kinect.Description.Height);
                        this.GenerateMesh(transformedPoints);
                        if (framesCounter == this.kinectAttributes.Interpolation)
                        {
                            sw.Close();
                            this.kinect.RemoveEventHandler(this.Reader_FrameArrived);
                        }
                    }
                }
            }                        
        }

        protected override void GenerateMesh(CameraSpacePoint[] points)
        {
            sw.WriteLine("\n# Frame cislo {0}",this.framesCounter);
            for (int i = 0; i < points.Length; i++)
            {
                CameraSpacePoint point = points[i];
                sw.WriteLine("v {0} {1} {2}", point.X.ToString(nfi), point.Y.ToString(nfi), point.Z.ToString(nfi));
            }

   /*       for (int i = 0; i < this.triangles.Count; i++)
            {
                sw.WriteLine("f {0} {1} {2}", this.triangles[i][0], this.triangles[i][1], this.triangles[i][2]);
            }           */
        }
    }
}
