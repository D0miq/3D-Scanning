﻿using Microsoft.Kinect;
using System.Collections.Generic;
using System.Windows.Forms;

namespace _3DScanning
{
    abstract class ASingleMeshGenerator : AMeshGenerator
    {
        /// <summary>
        /// List of frames
        /// </summary>
        protected List<ushort[]> framesList;

        protected ushort[] interpolatedDepths;

        protected ProgressBar progressBar;

        protected Label statusText;

        public ASingleMeshGenerator(ProgressBar progressBar, Label statusText)
        {
            this.progressBar = progressBar;
            this.statusText = statusText;
            this.framesList = new List<ushort[]>();
            this.interpolatedDepths = new ushort[this.depthFrameLength];
        }

        public override void Reader_FrameArrived(object sender, DepthFrameArrivedEventArgs e)
        {
            using (DepthFrame depthFrame = e.FrameReference.AcquireFrame())
            {
                if (depthFrame != null)
                {
                    using (KinectBuffer depthBuffer = depthFrame.LockImageBuffer())
                    {
                        ushort[] depthArray = GetDepthFromBuffer(depthBuffer);
                        this.framesCounter++;
                        this.progressBar.PerformStep();
                        this.framesList.Add(depthArray);
                        //When frames are stored interpolation begins
                        if (this.framesCounter == this.kinectAttributes.Interpolation)
                        {
                            this.InterpolateFrames();
                            this.progressBar.PerformStep();
                            this.kinect.Mapper.MapDepthFrameToCameraSpace(this.interpolatedDepths, this.csPoints);
                            CameraSpacePoint[] transformedPoints = this.CameraToWorldTransfer(this.kinect.Description.Width, this.kinect.Description.Height);
                            this.progressBar.PerformStep();
                            this.GenerateMesh(transformedPoints);
                          
                            this.statusText.Text = "Mesh byl vygenerován a uložen!";
                            this.progressBar.Hide();
                            this.progressBar.Value = 0;
                            this.framesList.Clear();
                            this.framesCounter = 0;
                            this.kinect.RemoveEventHandler(this.Reader_FrameArrived);
                        }
                    }
                }
            }
        }

        protected abstract void InterpolateFrames();

        protected int GetAverageDepth(int index)
        {
            int averageDepth = 0;
            int zeroCounter = 0;
            foreach (ushort[] depthArray in this.framesList)
            {
                if (depthArray[index] == 0)
                {
                    zeroCounter++;
                }
                averageDepth += depthArray[index];
            }
            if (averageDepth != 0)
            {
                averageDepth /= (this.framesList.Count - zeroCounter);
            }
            return averageDepth;
        }
    }
}
