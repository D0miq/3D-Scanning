﻿using Microsoft.Kinect;

namespace _3DScanning
{
    abstract class AMeshGenerator : APointCloudVisualisation
    {
        /// <summary>
        /// Counter of scanned frames
        /// </summary>
        protected int framesCounter = 0;

        public AMeshGenerator() { }

        protected abstract void GenerateMesh(CameraSpacePoint[] points);   
    }
}
