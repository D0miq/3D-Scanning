﻿

//using System.CodeDom.Compiler;
//using System.ComponentModel;
//using System.Diagnostics;
//using System.Drawing;
//using System.Globalization;
//using System.Resources;
//using System.Runtime.CompilerServices;

//namespace OpenTKLib.Properties
//{
//  [DebuggerNonUserCode]
//  [CompilerGenerated]
//  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "2.0.0.0")]
//  internal class Resources
//  {
//    private static ResourceManager resourceMan;
//    private static CultureInfo resourceCulture;

//    [EditorBrowsable(EditorBrowsableState.Advanced)]
//    internal static ResourceManager ResourceManager
//    {
//      get
//      {
//        if (object.ReferenceEquals((object) Resources.resourceMan, (object) null))
//          Resources.resourceMan = new ResourceManager("OpenTKLib.Properties.Resources", typeof (Resources).Assembly);
//        return Resources.resourceMan;
//      }
//    }

//    [EditorBrowsable(EditorBrowsableState.Advanced)]
//    internal static CultureInfo Culture
//    {
//      get
//      {
//        return Resources.resourceCulture;
//      }
//      set
//      {
//        Resources.resourceCulture = value;
//      }
//    }

//    internal static Bitmap animation
//    {
//      get
//      {
//        return (Bitmap) Resources.ResourceManager.GetObject("animation", Resources.resourceCulture);
//      }
//    }

//    internal static Bitmap del3D
//    {
//      get
//      {
//        return (Bitmap) Resources.ResourceManager.GetObject("del3D", Resources.resourceCulture);
//      }
//    }

//    internal static Bitmap highQuality
//    {
//      get
//      {
//        return (Bitmap) Resources.ResourceManager.GetObject("highQuality", Resources.resourceCulture);
//      }
//    }

//    internal static Bitmap highQuality3
//    {
//      get
//      {
//        return (Bitmap) Resources.ResourceManager.GetObject("highQuality3", Resources.resourceCulture);
//      }
//    }

//    internal static Bitmap lente
//    {
//      get
//      {
//        return (Bitmap) Resources.ResourceManager.GetObject("lente", Resources.resourceCulture);
//      }
//    }

//    internal static Bitmap lowQuality
//    {
//      get
//      {
//        return (Bitmap) Resources.ResourceManager.GetObject("lowQuality", Resources.resourceCulture);
//      }
//    }

//    internal static Bitmap lowQuality3
//    {
//      get
//      {
//        return (Bitmap) Resources.ResourceManager.GetObject("lowQuality3", Resources.resourceCulture);
//      }
//    }

//    internal static Bitmap open2
//    {
//      get
//      {
//        return (Bitmap) Resources.ResourceManager.GetObject("open2", Resources.resourceCulture);
//      }
//    }

//    internal static Bitmap RenderPoint
//    {
//      get
//      {
//        return (Bitmap) Resources.ResourceManager.GetObject("RenderPoint", Resources.resourceCulture);
//      }
//    }

//    internal static Bitmap RenderSolid
//    {
//      get
//      {
//        return (Bitmap) Resources.ResourceManager.GetObject("RenderSolid", Resources.resourceCulture);
//      }
//    }

//    internal static Bitmap RenderWire
//    {
//      get
//      {
//        return (Bitmap) Resources.ResourceManager.GetObject("RenderWire", Resources.resourceCulture);
//      }
//    }

//    internal static Bitmap veryhighQuality
//    {
//      get
//      {
//        return (Bitmap) Resources.ResourceManager.GetObject("veryhighQuality", Resources.resourceCulture);
//      }
//    }

//    internal static Bitmap veryhighQuality3
//    {
//      get
//      {
//        return (Bitmap) Resources.ResourceManager.GetObject("veryhighQuality3", Resources.resourceCulture);
//      }
//    }

//    internal Resources()
//    {
//    }
//  }
//}
