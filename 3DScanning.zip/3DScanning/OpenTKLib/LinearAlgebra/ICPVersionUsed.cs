﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenTKLib
{
    public enum ICP_VersionUsed
    {
        Horn,
        Scaling_Umeyama,
        Scaling_Zinsser,
        Scaling_Du,
        UsingStitchData,
        RandomPoints
    }

    
}
